export const productsData = [
    {
        id: 'wood-pencil',
        name: 'Wood Pencil',
        price: 19.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image1.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image1.jpg'
            },
        ]
    },
    {
        id: 't-shirt',
        name: 'T-Shirt',
        price: 22.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image2.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image2.jpg'
            },
        ]
    },
    {
        id: 'casual-shoe',
        name: 'Casual Shoe',
        price: 31.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image3.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image3.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image2.jpg'
            },
        ]
    },
    {
        id: 'coffee-bag',
        name: 'Coffee Bag',
        price: 4.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image4.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image4.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image4.jpg'
            },
        ]
    },
    {
        id: 'single-chair',
        name: 'Single Chair',
        price: 149.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image5.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image5.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image4.jpg'
            },
        ]
    },
    {
        id: 'business-card',
        name: 'Business Card',
        price: 1.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image6.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image6.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image4.jpg'
            },
        ]
    },
    {
        id: 'book-cover',
        name: 'Book Cover',
        price: 3.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image7.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image7.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image4.jpg'
            },
        ]
    },
    {
        id: 'wall-watch',
        name: 'Wall Watch',
        price: 9.99,
        desc: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.",
        availability: 'In Stock',
        image: '/images/shop-image/shop-image8.jpg',
        images: [
            {
                id: 1,
                img: '/images/shop-image/shop-image8.jpg'
            },
            {
                id: 2,
                img: '/images/shop-image/shop-image2.jpg'
            },
            {
                id: 3,
                img: '/images/shop-image/shop-image1.jpg'
            },
            {
                id: 4,
                img: '/images/shop-image/shop-image4.jpg'
            },
        ]
    },
]